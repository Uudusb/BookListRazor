﻿namespace BookListRazor
{
    internal class ApplicaionDbContext
    {
    }
}